# SeaVees — Consolidated Findings & Recommendations (password-protected)

Static single-page report behind a password. No build step, no dependencies, no framework, no Vercel configuration required.

**Access password: `SeaVees2026`**

## Deploy to Vercel

```bash
npm i -g vercel      # once
cd seavees-report-protected
vercel               # preview URL
vercel --prod        # production URL
```

Framework preset **Other**. Leave build command and output directory blank. Or push to a Git repo and import at vercel.com/new, or drag the folder onto vercel.com/new.

Nothing needs to be switched on in the Vercel dashboard — the protection travels inside `index.html`.

## How the protection actually works

This is **real encryption**, not a hidden `<div>` that JavaScript reveals.

At build time the entire report was encrypted with **AES-256-GCM**. The key is derived from the password with **PBKDF2-HMAC-SHA256 at 600,000 iterations** over a random 16-byte salt, with a random 12-byte IV and a 128-bit authentication tag. The deployed file contains only ciphertext.

When a reader enters the password, the browser derives the key with WebCrypto, decrypts in memory, and writes the report into the page. Unlock takes roughly half a second.

**What this means in practice:** viewing source, opening devtools, disabling JavaScript, or deleting elements will not reveal the report. The plaintext is not in the file. Verified — none of the report's content strings appear anywhere in the deployed bytes.

## What it does not protect against — read this

**The password is the whole of the security.** Anyone who has it, or is given it, has the report permanently and can save the decrypted page.

**An attacker who downloads the file can attempt an offline brute-force.** There is no server to rate-limit guesses. `SeaVees2026` is a short, guessable, brand-and-year password; the 600,000 PBKDF2 iterations slow each guess down considerably, but they do not make a predictable password safe against a determined attacker who has the file and cares enough.

That is a reasonable trade for a client convenience gate. It is **not** equivalent to server-side authentication. If this report needs to be genuinely locked down rather than reasonably shielded, use **Vercel Settings → Deployment Protection → Vercel Authentication** in addition — the two work together, and Vercel's gate stops the file being downloaded at all.

## Changing the password

Edit `PASSWORD` in `build_gate.py`, then rebuild:

```bash
pip install cryptography
python3 build_gate.py index-plain.html index.html
```

The script needs the **unencrypted** report as input. Keep `index-plain.html` (the unprotected build) somewhere private — it is the master copy, and the encrypted file cannot be edited directly.

A longer passphrase costs the reader nothing and buys real resistance. Something like `seavees-harbor-audit-2026` is far stronger than `SeaVees2026` and no harder to paste into an email.

## Reader experience

- Password prompt on first visit; **Enter** submits.
- Wrong password gives a plain error and clears the field. No lockout.
- Unlocking is remembered for the **browser session only** — reloads and deep links do not re-prompt. Closing the tab clears it. Nothing is written to permanent storage or cookies.
- Deep links survive the gate: `.../#p10` prompts for the password, then opens the EBITDA bridge tab directly.
- Works on mobile; the gate is responsive at 390px.
- Requires WebCrypto, which needs **https** or localhost. Vercel is https by default. Opening `index.html` from the filesystem (`file://`) will not decrypt in some browsers — serve it or deploy it.

## Files

| File | Purpose |
|---|---|
| `index.html` | Password gate plus the encrypted report. The only file that must deploy. |
| `index-plain.html` | **Unencrypted master copy. Do not deploy this.** Kept so you can edit and rebuild. |
| `build_gate.py` | Encrypts `index-plain.html` into `index.html`. Needs `cryptography`. |
| `vercel.json` | `noindex` plus security headers. |
| `robots.txt` | Disallow all crawlers. |
| `.vercelignore` | Keeps this README, the plain copy and the build script out of the deployment. |

`.vercelignore` excludes `index-plain.html` and `build_gate.py`, so the unprotected report is not published even though it sits in this folder. Confirm that before your first `--prod` deploy.

## Notes

- Fonts load from Google Fonts. If blocked, the page falls back to system serif/sans and stays legible.
- Light/dark toggle, expand-all, search and print all work normally after unlock.
- Print/PDF: only the open tab prints — open the tab you want first.
